package es.uva.poo.strategy;

/**
 * EstrategiaRutaBicicleta (ConcreteStrategy).
 * 
 * <p>Implementa el algoritmo de construcción de ruta para viajar en bicicleta.</p>
 * 
 * @author Diego
 */
public class EstrategiaRutaBicicleta implements EstrategiaRuta {

    /**
     * Construye una ruta para bicicleta.
     * 
     * @param origen  Punto de partida.
     * @param destino Punto final.
     */
    @Override
    public void construirRuta(String origen, String destino) {
        System.out.println("Ruta en BICICLETA: " + origen + " -> " + destino);
        System.out.println("  1) Priorizar carriles bici y calles tranquilas");
        System.out.println("  2) Evitar pendientes pronunciadas si es posible");
        System.out.println("  3) Estimar esfuerzo y tiempo de llegada");
    }
}
