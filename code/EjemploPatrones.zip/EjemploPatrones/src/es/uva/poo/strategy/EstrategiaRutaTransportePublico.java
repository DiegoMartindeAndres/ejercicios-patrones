package es.uva.poo.strategy;

/**
 * EstrategiaRutaTransportePublico (ConcreteStrategy).
 * 
 * <p>Implementa el algoritmo de construcción de ruta para transporte público.</p>
 * 
 * @author Diego
 */
public class EstrategiaRutaTransportePublico implements EstrategiaRuta {

    /**
     * Construye una ruta usando transporte público.
     * 
     * @param origen  Punto de partida.
     * @param destino Punto final.
     */
    @Override
    public void construirRuta(String origen, String destino) {
        System.out.println("Ruta en TRANSPORTE PÚBLICO: " + origen + " -> " + destino);
        System.out.println("  1) Buscar líneas de bus/metro/tren disponibles");
        System.out.println("  2) Calcular transbordos y tiempos de espera");
        System.out.println("  3) Estimar el tiempo total de llegada");
    }
}
