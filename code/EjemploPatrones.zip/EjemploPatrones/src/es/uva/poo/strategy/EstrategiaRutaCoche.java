package es.uva.poo.strategy;

/**
 * EstrategiaRutaCoche (ConcreteStrategy).
 * 
 * <p>Implementa el algoritmo de construcción de ruta para viajar en coche.</p>
 * 
 * @author Diego
 */
public class EstrategiaRutaCoche implements EstrategiaRuta {

    /**
     * Construye una ruta para coche.
     * 
     * @param origen  Punto de partida.
     * @param destino Punto final.
     */
    @Override
    public void construirRuta(String origen, String destino) {
        System.out.println("Ruta en COCHE: " + origen + " -> " + destino);
        System.out.println("  1) Buscar carreteras principales");
        System.out.println("  2) Evitar peajes si está configurado");
        System.out.println("  3) Estimar tráfico y tiempo de llegada");
    }
}
