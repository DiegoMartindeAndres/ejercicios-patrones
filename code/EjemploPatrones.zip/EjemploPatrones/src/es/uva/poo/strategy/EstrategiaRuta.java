package es.uva.poo.strategy;

/**
 * Interfaz EstrategiaRuta (Strategy).
 * 
 * <p>Declara la operación que todas las estrategias concretas deben implementar.
 * El objetivo es poder intercambiar el algoritmo de cálculo/construcción de
 * ruta sin modificar al cliente ni al contexto.</p>
 * 
 * <p>En este ejemplo, la estrategia se limita a "construir" una ruta e imprimir
 * los pasos (para mantener el ejemplo sencillo y auto-contenido).</p>
 * 
 * @author Diego
 */
public interface EstrategiaRuta {

    /**
     * Construye (o calcula) una ruta entre un origen y un destino.
     * 
     * @param origen  Punto de partida.
     * @param destino Punto final.
     */
    void construirRuta(String origen, String destino);
}
