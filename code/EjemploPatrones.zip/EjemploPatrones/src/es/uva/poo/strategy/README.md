# Patrón Strategy (Estrategia) - Ejemplo en Java

Este directorio contiene un ejemplo de implementación del patrón de diseño **Strategy (Estrategia)** en Java.

## Descripción del Ejemplo

El ejemplo simula un **navegador** que puede construir rutas entre un origen y un destino.
La forma de construir la ruta (el algoritmo) se encapsula en una interfaz `EstrategiaRuta` y varias estrategias concretas:

- `EstrategiaRutaCoche`: ruta para coche.
- `EstrategiaRutaBicicleta`: ruta para bicicleta.
- `EstrategiaRutaTransportePublico`: ruta usando transporte público.

El **contexto** `Navegador` delega el cálculo/construcción en la estrategia actual, y el **cliente** (`Demo`) puede cambiarla en tiempo de ejecución.

El código se encuentra en el paquete `es.uva.poo.strategy`.

## Diagrama de clases (Mermaid)

```mermaid
classDiagram

class EstrategiaRuta {
  <<interface>>
  +construirRuta(String origen, String destino) void
}

class EstrategiaRutaCoche {
  +construirRuta(String origen, String destino) void
}

class EstrategiaRutaBicicleta {
  +construirRuta(String origen, String destino) void
}

class EstrategiaRutaTransportePublico {
  +construirRuta(String origen, String destino) void
}

class Navegador {
  -estrategia: EstrategiaRuta
  +Navegador(EstrategiaRuta estrategia)
  +setEstrategia(EstrategiaRuta estrategia) void
  +construirRuta(String origen, String destino) void
}

class Demo {
  +main(String[]) void
}

EstrategiaRuta <|.. EstrategiaRutaCoche
EstrategiaRuta <|.. EstrategiaRutaBicicleta
EstrategiaRuta <|.. EstrategiaRutaTransportePublico

Navegador --> EstrategiaRuta : usa
Demo ..> Navegador : crea/usa
Demo ..> EstrategiaRuta : selecciona/inyecta
```

## Estructura de Ficheros

A continuación se describen los ficheros en el orden sugerido de creación/lectura para entender el patrón:

1. **EstrategiaRuta.java** (Strategy): Interfaz común que define el algoritmo intercambiable.
2. **EstrategiaRutaCoche.java** (ConcreteStrategy): Implementación concreta para construir rutas en coche.
3. **EstrategiaRutaBicicleta.java** (ConcreteStrategy): Implementación concreta para construir rutas en bicicleta.
4. **EstrategiaRutaTransportePublico.java** (ConcreteStrategy): Implementación concreta para transporte público.
5. **Navegador.java** (Context): Mantiene una referencia a `EstrategiaRuta` y delega en ella.
6. **Demo.java** (Cliente): Crea el contexto, inyecta la estrategia inicial y la cambia en ejecución.

