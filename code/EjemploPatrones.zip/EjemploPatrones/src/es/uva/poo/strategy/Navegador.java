package es.uva.poo.strategy;

/**
 * Navegador (Context).
 * 
 * <p>El contexto mantiene una referencia a una EstrategiaRuta (Strategy).
 * El contexto delega la parte variable (el algoritmo de ruta) en la estrategia.
 * Así podemos cambiar el comportamiento en tiempo de ejecución.</p>
 * 
 * @author Diego
 */
public class Navegador {

    private EstrategiaRuta estrategia;

    /**
     * Crea un navegador con una estrategia inicial.
     * 
     * @param estrategia Estrategia a usar inicialmente.
     */
    public Navegador(EstrategiaRuta estrategia) {
        this.estrategia = estrategia;
    }

    /**
     * Cambia la estrategia de ruta en tiempo de ejecución.
     * 
     * @param estrategia Nueva estrategia.
     */
    public void setEstrategia(EstrategiaRuta estrategia) {
        this.estrategia = estrategia;
    }

    /**
     * Construye una ruta delegando el algoritmo en la estrategia actual.
     * 
     * @param origen  Punto de partida.
     * @param destino Punto final.
     */
    public void construirRuta(String origen, String destino) {
        if (estrategia == null) {
            throw new IllegalStateException("No hay estrategia configurada en el Navegador.");
        }
        estrategia.construirRuta(origen, destino);
    }
}
