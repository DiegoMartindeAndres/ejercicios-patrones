package es.uva.poo.strategy;

/**
 * Demo.
 * 
 * <p>Ejemplo de uso del patrón Strategy. El cliente (este main) crea el contexto
 * (Navegador) y le inyecta una estrategia concreta. Después puede cambiar la
 * estrategia sin modificar el código del contexto.</p>
 * 
 * <p>Basado en el ejemplo de Refactoring.Guru del patrón Strategy (ruteo),
 * adaptado a nombres en español.</p>
 * 
 * @author Diego
 */
public class Demo {

    /**
     * Punto de entrada.
     * 
     * @param args Argumentos de línea de comandos (opcional).
     */
    public static void main(String[] args) {
        String origen = "Valladolid";
        String destino = "Madrid";

        System.out.println("--- Strategy: Ruta en coche ---");
        Navegador navegador = new Navegador(new EstrategiaRutaCoche());
        navegador.construirRuta(origen, destino);

        System.out.println("\n--- Cambio de estrategia: Bicicleta ---");
        navegador.setEstrategia(new EstrategiaRutaBicicleta());
        navegador.construirRuta(origen, destino);

        System.out.println("\n--- Cambio de estrategia: Transporte público ---");
        navegador.setEstrategia(new EstrategiaRutaTransportePublico());
        navegador.construirRuta(origen, destino);
    }
}
