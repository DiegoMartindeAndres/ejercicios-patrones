package es.uva.poo.composite;

/**
 * Hoja (Leaf)
 *
 * Otro gráfico simple: un círculo.
 */
public class Circulo extends FormaBase {

    private int radio;

    public Circulo(int x, int y, int radio, String color) {
        super(x, y, color);
        this.radio = radio;
    }

    public int getRadio() {
        return radio;
    }

    public void setRadio(int radio) {
        this.radio = radio;
    }

    @Override
    public void dibujar() {
        System.out.println("Círculo(" + descripcionComun() + ", radio=" + radio + ")");
    }
}
