package es.uva.poo.composite;

import java.util.ArrayList;
import java.util.List;

/**
 * Cliente (Client)
 *
 * Simula un "editor de imagen" que trabaja con gráficos sin distinguir
 * si son hojas (Punto, Círculo) o compuestos (CompuestoGrafico).
 *
 * La clave del Composite es precisamente esta: el cliente usa la interfaz
 * común (Grafico) y puede componer estructuras en árbol.
 */
public class EditorDeImagen {

    private final List<Grafico> todosLosGraficos = new ArrayList<>();

    /**
     * Carga una escena inicial con formas simples.
     */
    public void cargar() {
        Grafico punto = new Punto(10, 20, "Negro");
        Grafico circulo = new Circulo(30, 40, 15, "Rojo");
        Grafico circulo2 = new Circulo(80, 25, 10, "Azul");

        todosLosGraficos.add(punto);
        todosLosGraficos.add(circulo);
        todosLosGraficos.add(circulo2);
    }

    /**
     * Agrupa los dos primeros elementos (simulando una selección en UI).
     *
     * Devuelve el grupo creado para que el cliente pueda operarlo también.
     */
    public CompuestoGrafico agruparSeleccion() {
        if (todosLosGraficos.size() < 2) {
            throw new IllegalStateException("Se necesitan al menos 2 gráficos para agrupar");
        }

        Grafico primero = todosLosGraficos.get(0);
        Grafico segundo = todosLosGraficos.get(1);

        // Creamos el compuesto (grupo) y metemos dentro los seleccionados.
        CompuestoGrafico grupo = new CompuestoGrafico("Selección");
        grupo.agregar(primero);
        grupo.agregar(segundo);

        // Quitamos los elementos sueltos del nivel raíz y añadimos el grupo.
        todosLosGraficos.remove(primero);
        todosLosGraficos.remove(segundo);
        todosLosGraficos.add(grupo);

        return grupo;
    }

    public void moverTodo(int dx, int dy) {
        for (Grafico grafico : todosLosGraficos) {
            grafico.mover(dx, dy);
        }
    }

    public void dibujar() {
        System.out.println("=== Escena actual ===");
        for (Grafico grafico : todosLosGraficos) {
            grafico.dibujar();
        }
    }
}
