package es.uva.poo.composite;

/**
 * Hoja (Leaf)
 *
 * Un gráfico simple que no contiene otros gráficos.
 */
public class Punto extends FormaBase {

    public Punto(int x, int y, String color) {
        super(x, y, color);
    }

    @Override
    public void dibujar() {
        System.out.println("Punto(" + descripcionComun() + ")");
    }
}
