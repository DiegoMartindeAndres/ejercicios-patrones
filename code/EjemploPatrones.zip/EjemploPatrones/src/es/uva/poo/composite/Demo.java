package es.uva.poo.composite;

/**
 * Demo / Punto de entrada.
 *
 * Muestra cómo un cliente puede trabajar con objetos simples (hojas)
 * y con objetos compuestos (grupos) usando la misma interfaz (Grafico).
 */
public class Demo {

    public static void main(String[] args) {
        EditorDeImagen editor = new EditorDeImagen();

        // 1) Cargamos una escena con hojas.
        editor.cargar();
        editor.dibujar();

        // 2) Agrupamos una "selección" (crea un CompuestoGrafico).
        editor.agruparSeleccion();
        System.out.println();
        editor.dibujar();

        // 3) Movemos todo. Observa que el grupo mueve a sus hijos.
        editor.moverTodo(5, -10);
        System.out.println();
        editor.dibujar();
    }
}
