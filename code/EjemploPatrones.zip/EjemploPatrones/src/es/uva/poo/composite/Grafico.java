package es.uva.poo.composite;

/**
 * Componente (Component)
 *
 * Declara la interfaz común para:
 * - Hojas (objetos simples, como un Punto o un Círculo)
 * - Compuestos (contenedores de gráficos, como un grupo)
 *
 * En el ejemplo de Refactoring.Guru, este rol se llama "Graphic".
 */
public interface Grafico {

    /**
     * Mueve el gráfico una cantidad (dx, dy).
     *
     * Nota: en un compuesto, esta operación se delega a todos los hijos.
     */
    void mover(int dx, int dy);

    /**
     * Dibuja el gráfico.
     *
     * En una aplicación real, esto pintaría en un canvas.
     * Aquí solo escribimos por consola para ver el comportamiento.
     */
    void dibujar();
}
