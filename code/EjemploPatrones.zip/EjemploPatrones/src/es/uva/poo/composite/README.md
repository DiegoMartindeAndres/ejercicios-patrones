# Patrón Composite (Compuesto) — Ejemplo en Java

Este directorio contiene un ejemplo del patrón de diseño **Composite** en Java.

La idea principal del patrón es permitir tratar de forma uniforme:
- **Objetos simples** (Hojas / *Leaf*)
- **Estructuras compuestas** (Compuestos / *Composite*)

Ambos exponen la misma interfaz (Componente / *Component*). Así, el cliente no necesita saber si está trabajando con un objeto individual o con un grupo.

Este ejemplo está inspirado en el de Refactoring.Guru ("Graphic" / "CompoundGraphic"), adaptado con nombres en español y salida por consola.

## Paquete

El código se encuentra en el paquete `es.uva.poo.composite`.

## Estructura de ficheros (orden recomendado)

1. **Grafico.java** (Componente / *Component*)
   - Interfaz común con las operaciones `mover(dx, dy)` y `dibujar()`.

2. **FormaBase.java** (Base para hojas)
   - Clase abstracta con estado común (posición y color) y una implementación por defecto de `mover`.

3. **Punto.java** (Hoja / *Leaf*)
   - Implementación simple de `Grafico`.

4. **Circulo.java** (Hoja / *Leaf*)
   - Otra hoja (incluye un atributo extra: `radio`).

5. **CompuestoGrafico.java** (Compuesto / *Composite*)
   - Contenedor de `Grafico` que implementa la misma interfaz.
   - Delegación: `mover` y `dibujar` se aplican a todos los hijos.

6. **EditorDeImagen.java** (Cliente / *Client*)
   - Trabaja con `Grafico` sin distinguir hojas y compuestos.
   - Simula una selección y agrupación (crea un `CompuestoGrafico`).

7. **Demo.java** (Ejecución)
   - Contiene el `main` y muestra una ejecución típica:
     1) crear hojas
     2) agrupar elementos
     3) mover y dibujar la estructura

## Diagrama de clases (Mermaid)

El siguiente diagrama resume la estructura del ejemplo y las relaciones principales del patrón **Composite** (hojas y compuestos comparten la misma interfaz `Grafico`):

```mermaid
classDiagram
   

   class Grafico {
      <<interface>>
      +mover(int dx, int dy)
      +dibujar()
   }

   class FormaBase {
      <<abstract>>
      #int x
      #int y
      #String color
      +mover(int dx, int dy)
      #descripcionComun() String
   }
   Grafico <|.. FormaBase

   class Punto {
      +Punto(int x, int y, String color)
      +dibujar()
   }
   FormaBase <|-- Punto

   class Circulo {
      -int radio
      +Circulo(int x, int y, int radio, String color)
      +getRadio() int
      +setRadio(int radio)
      +dibujar()
   }
   FormaBase <|-- Circulo

   class CompuestoGrafico {
      -String nombre
      -List~Grafico~ hijos
      +CompuestoGrafico(String nombre)
      +agregar(Grafico grafico)
      +eliminar(Grafico grafico)
      +getHijos() List~Grafico~
      +mover(int dx, int dy)
      +dibujar()
   }
   Grafico <|.. CompuestoGrafico
   CompuestoGrafico *-- "0..*" Grafico : hijos

   class EditorDeImagen {
      -List~Grafico~ todosLosGraficos
      +cargar()
      +agruparSeleccion() CompuestoGrafico
      +moverTodo(int dx, int dy)
      +dibujar()
   }
   EditorDeImagen o-- "0..*" Grafico : escena

   class Demo {
      +main(String[] args)
   }
   Demo --> EditorDeImagen : usa
```

## Compilar y ejecutar

Desde la carpeta raíz `code/`:

```bash
javac es/uva/poo/composite/*.java
java es.uva.poo.composite.Demo
```

## Qué observar en la salida

- Antes de agrupar: hay varios gráficos sueltos.
- Después de agrupar: aparece un **grupo** que contiene varios gráficos.
- Al mover todo: el grupo desplaza a sus hijos, demostrando la delegación del Composite.
