package es.uva.poo.composite;

/**
 * Clase base para formas simples (Hojas).
 *
 * En el ejemplo de Refactoring.Guru, existe una clase base "BaseShape"
 * que implementa parte de la lógica común (posición, color, etc.).
 */
public abstract class FormaBase implements Grafico {

    protected int x;
    protected int y;
    protected String color;

    protected FormaBase(int x, int y, String color) {
        this.x = x;
        this.y = y;
        this.color = color;
    }

    @Override
    public void mover(int dx, int dy) {
        this.x += dx;
        this.y += dy;
    }

    protected String descripcionComun() {
        return "x=" + x + ", y=" + y + ", color=" + color;
    }
}
