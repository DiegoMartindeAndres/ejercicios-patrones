package es.uva.poo.composite;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Compuesto (Composite)
 *
 * Contiene otros gráficos (hijos) y expone la MISMA interfaz que una Hoja.
 * Así, el cliente puede tratar igual un objeto simple y un grupo.
 *
 * En el ejemplo de Refactoring.Guru, este rol se llama "CompoundGraphic".
 */
public class CompuestoGrafico implements Grafico {

    private final String nombre;
    private final List<Grafico> hijos = new ArrayList<>();

    public CompuestoGrafico(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Añade un hijo al compuesto.
     */
    public void agregar(Grafico grafico) {
        if (grafico == null) {
            throw new IllegalArgumentException("El gráfico no puede ser null");
        }
        hijos.add(grafico);
    }

    /**
     * Elimina un hijo del compuesto (si existe).
     */
    public void eliminar(Grafico grafico) {
        hijos.remove(grafico);
    }

    /**
     * Devuelve una vista de solo lectura de los hijos.
     */
    public List<Grafico> getHijos() {
        return Collections.unmodifiableList(hijos);
    }

    @Override
    public void mover(int dx, int dy) {
        // Un compuesto no se mueve “a sí mismo”; mueve a todos sus hijos.
        for (Grafico hijo : hijos) {
            hijo.mover(dx, dy);
        }
    }

    @Override
    public void dibujar() {
        System.out.println("Grupo '" + nombre + "' (" + hijos.size() + " elementos):");
        for (Grafico hijo : hijos) {
            // Para visualizar jerarquía, dibujamos cada hijo con una sangría simple.
            System.out.print("  - ");
            hijo.dibujar();
        }
    }
}
