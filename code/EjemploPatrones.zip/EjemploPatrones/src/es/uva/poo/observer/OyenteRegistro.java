package es.uva.poo.observer;

import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;

/**
 * Observador concreto.
 *
 * Registra ("log") los eventos en un fichero de texto.
 */
public class OyenteRegistro implements OyenteEvento {

    private final String rutaLog;

    public OyenteRegistro(String rutaLog) {
        this.rutaLog = rutaLog;
    }

    @Override
    public void actualizar(String tipoEvento, String datos) {
        String linea = String.format("%s - Evento '%s' sobre '%s'%n", LocalDateTime.now(), tipoEvento, datos);

        try (FileWriter writer = new FileWriter(rutaLog, true)) {
            writer.write(linea);
        } catch (IOException ex) {
            // Para un ejemplo didáctico, basta con reportarlo por consola.
            System.err.println("No se pudo escribir en el log '" + rutaLog + "': " + ex.getMessage());
        }
    }
}
