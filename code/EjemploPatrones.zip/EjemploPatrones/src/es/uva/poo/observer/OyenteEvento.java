package es.uva.poo.observer;

/**
 * Interfaz del patrón Observer.
 *
 * Un {@code OyenteEvento} (Observer) se registra en un {@link GestorEventos}
 * para ser notificado cuando ocurre un determinado tipo de evento.
 */
public interface OyenteEvento {

    /**
     * Método llamado por el publicador cuando ocurre un evento.
     *
     * @param tipoEvento Tipo de evento (por ejemplo, "abrir" o "guardar").
     * @param datos      Información asociada al evento (por ejemplo, nombre del archivo).
     */
    void actualizar(String tipoEvento, String datos);
}
