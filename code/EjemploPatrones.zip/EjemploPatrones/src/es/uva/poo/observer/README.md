# Patrón de Diseño Observer (Observador)

Este ejemplo implementa el patrón **Observer** en Java (basado en la estructura del ejemplo de refactoring.guru), usando un **Editor** que publica eventos (abrir/guardar) y varios **oyentes** que reaccionan a esos eventos.

## Estructura del Código

El código se encuentra en el paquete `es.uva.poo.observer`.

### 1. Interfaz del Observador (Observer)
Define el contrato que deben cumplir los observadores para recibir notificaciones.
- `OyenteEvento.java`: Interfaz con el método `actualizar(tipoEvento, datos)`.

### 2. Gestor de eventos (Subject/Publisher helper)
Mantiene las listas de suscriptores y se encarga de notificar.
- `GestorEventos.java`: Permite `suscribir`, `cancelar` y `notificar` por **tipo de evento**.

### 3. Publicador concreto (Concrete Publisher)
Clase que dispara eventos cuando ocurren acciones.
- `Editor.java`: Tiene un `GestorEventos` y notifica eventos al `abrirArchivo(...)` y `guardarArchivo()`.

### 4. Observadores concretos (Concrete Observers)
Implementan reacciones concretas cuando se produce un evento.
- `OyenteNotificacionEmail.java`: Simula enviar un email (imprime por consola).
- `OyenteRegistro.java`: Registra los eventos en un fichero `eventos.log`.

### 5. Demo
- `Demo.java`: Crea el editor, suscribe oyentes a los eventos y ejecuta la simulación.

## Orden recomendado de creación (para estudiar el patrón)

1. Crear la interfaz `OyenteEvento`.
2. Crear el `GestorEventos` (gestiona suscripciones y notificaciones).
3. Crear el publicador `Editor` (usa `GestorEventos` para emitir eventos).
4. Crear observadores concretos (`OyenteNotificacionEmail`, `OyenteRegistro`).
5. Crear `Demo` para conectar todo y ejecutar.

## Diagrama de clases (Mermaid)

```mermaid
classDiagram

class OyenteEvento {
  <<interface>>
  +actualizar(tipoEvento: String, datos: String) void
}

class GestorEventos {
  -oyentesPorEvento: Map~String, List~OyenteEvento~~
  +suscribir(tipoEvento: String, oyente: OyenteEvento) void
  +cancelar(tipoEvento: String, oyente: OyenteEvento) void
  +notificar(tipoEvento: String, datos: String) void
}

class Editor {
  +eventos: GestorEventos
  -archivo: File
  +abrirArchivo(ruta: String) void
  +guardarArchivo() void
}

class OyenteNotificacionEmail {
  -emailDestino: String
  +actualizar(tipoEvento: String, datos: String) void
}

class OyenteRegistro {
  -rutaLog: String
  +actualizar(tipoEvento: String, datos: String) void
}

class Demo

OyenteEvento <|.. OyenteNotificacionEmail
OyenteEvento <|.. OyenteRegistro

GestorEventos o--> "*" OyenteEvento : suscriptores
Editor --> GestorEventos : usa
Demo ..> Editor : crea/ejecuta
```

