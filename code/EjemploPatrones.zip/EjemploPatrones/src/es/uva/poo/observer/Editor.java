package es.uva.poo.observer;

import java.io.File;

/**
 * Clase "Publicador" (Publisher) que genera eventos.
 *
 * El editor no conoce a los oyentes concretos. Solo expone un {@link GestorEventos}
 * para que otros se suscriban y reaccionen a sus eventos.
 */
public class Editor {

    /**
     * Gestor de eventos usado para suscribir oyentes y notificar eventos.
     *
     * Se deja público para simplificar el ejemplo (como en refactoring.guru),
     * aunque en un diseño más estricto se podrían exponer métodos delegados.
     */
    public final GestorEventos eventos;

    private File archivo;

    public Editor() {
        this.eventos = new GestorEventos();
    }

    /**
     * Simula abrir un archivo.
     *
     * @param ruta Ruta del archivo a abrir.
     */
    public void abrirArchivo(String ruta) {
        this.archivo = new File(ruta);
        eventos.notificar("abrir", archivo.getName());
    }

    /**
     * Simula guardar el archivo actual.
     */
    public void guardarArchivo() {
        if (archivo == null) {
            throw new IllegalStateException("No hay ningún archivo abierto para guardar");
        }
        eventos.notificar("guardar", archivo.getName());
    }
}
