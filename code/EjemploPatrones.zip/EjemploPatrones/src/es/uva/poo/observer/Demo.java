package es.uva.poo.observer;

/**
 * Demo del patrón Observer.
 *
 * Se crean observadores (oyentes), se suscriben a eventos del editor y se provoca
 * la emisión de eventos al abrir y guardar un archivo.
 */
public class Demo {

    public static void main(String[] args) {
        Editor editor = new Editor();

        // Observadores concretos
        OyenteEvento notificador = new OyenteNotificacionEmail("profesor@universidad.es");
        OyenteEvento registro = new OyenteRegistro("eventos.log");

        // Suscripciones por tipo de evento
        editor.eventos.suscribir("abrir", notificador);
        editor.eventos.suscribir("guardar", notificador);
        editor.eventos.suscribir("abrir", registro);
        editor.eventos.suscribir("guardar", registro);

        // Acciones que disparan eventos
        editor.abrirArchivo("ejemplo.txt");
        editor.guardarArchivo();
    }
}
