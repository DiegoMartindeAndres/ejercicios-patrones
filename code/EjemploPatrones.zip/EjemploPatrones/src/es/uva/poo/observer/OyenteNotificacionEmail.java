package es.uva.poo.observer;

/**
 * Observador concreto.
 *
 * Simula el envío de un correo cada vez que ocurre un evento concreto.
 */
public class OyenteNotificacionEmail implements OyenteEvento {

    private final String emailDestino;

    public OyenteNotificacionEmail(String emailDestino) {
        this.emailDestino = emailDestino;
    }

    @Override
    public void actualizar(String tipoEvento, String datos) {
        // En un sistema real aquí iría el envío de email. Para el ejemplo, imprimimos por consola.
        System.out.printf("[EMAIL -> %s] Evento '%s' sobre '%s'%n", emailDestino, tipoEvento, datos);
    }
}
