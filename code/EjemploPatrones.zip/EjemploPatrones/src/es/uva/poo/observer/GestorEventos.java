package es.uva.poo.observer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * El "sujeto"/publicador del patrón Observer.
 *
 * En lugar de tener una lista única de observadores, gestionamos suscripciones
 * por tipo de evento (como en el ejemplo de refactoring.guru).
 */
public class GestorEventos {

    /**
     * Mapa: tipo de evento -> lista de oyentes suscritos.
     */
    private final Map<String, List<OyenteEvento>> oyentesPorEvento = new HashMap<>();

    /**
     * Registra un oyente para un tipo de evento.
     *
     * @param tipoEvento Tipo de evento.
     * @param oyente     Observador a suscribir.
     */
    public void suscribir(String tipoEvento, OyenteEvento oyente) {
        oyentesPorEvento.computeIfAbsent(tipoEvento, k -> new ArrayList<>()).add(oyente);
    }

    /**
     * Elimina la suscripción de un oyente para un tipo de evento.
     *
     * @param tipoEvento Tipo de evento.
     * @param oyente     Observador a cancelar.
     */
    public void cancelar(String tipoEvento, OyenteEvento oyente) {
        List<OyenteEvento> oyentes = oyentesPorEvento.get(tipoEvento);
        if (oyentes == null) {
            return;
        }
        oyentes.remove(oyente);
    }

    /**
     * Notifica a todos los oyentes suscritos a un tipo de evento.
     *
     * @param tipoEvento Tipo de evento.
     * @param datos      Datos del evento.
     */
    public void notificar(String tipoEvento, String datos) {
        List<OyenteEvento> oyentes = oyentesPorEvento.get(tipoEvento);
        if (oyentes == null) {
            return;
        }

        // Copia defensiva para evitar problemas si un oyente se desuscribe durante la notificación.
        List<OyenteEvento> snapshot = new ArrayList<>(oyentes);
        for (OyenteEvento oyente : snapshot) {
            oyente.actualizar(tipoEvento, datos);
        }
    }
}
