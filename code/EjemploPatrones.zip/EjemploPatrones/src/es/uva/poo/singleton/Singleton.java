package es.uva.poo.singleton;

/**
 * Clase que implementa el patrón de diseño Singleton (Instancia Única).
 * Garantiza que solo exista una instancia de esta clase en toda la aplicación.
 */
public class Singleton {
    
    // Variable estática privada que almacena la única instancia de la clase.
    // Inicialmente es null hasta que se llame al método obtenerInstancia().
    private static Singleton instancia;

    /**
     * Constructor privado.
     * Es crucial que sea privado para evitar que otras clases puedan instanciarlo
     * usando el operador 'new'.
     */
    private Singleton() {
        System.out.println("INFO: Inicializando la instancia única del Singleton...");
    }

    /**
     * Método público estático para obtener la instancia única.
     * Implementa 'Lazy Initialization' (Inicialización perezosa):
     * La instancia solo se crea cuando se necesita por primera vez.
     * 
     * @return La única instancia de la clase Singleton.
     */
    public static Singleton obtenerInstancia() {
        if (instancia == null) {
            instancia = new Singleton();
        }
        return instancia;
    }

    /**
     * Un método de ejemplo para demostrar la funcionalidad de la instancia.
     */
    public void mostrarMensaje() {
        System.out.println("¡Hola! Soy la única instancia del Singleton en funcionamiento.");
    }
}
