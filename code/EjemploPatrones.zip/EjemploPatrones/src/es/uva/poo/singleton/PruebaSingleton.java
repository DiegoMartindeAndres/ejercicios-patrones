package es.uva.poo.singleton;

/**
 * Clase de prueba para verificar el comportamiento del patrón Singleton.
 */
public class PruebaSingleton {

    public static void main(String[] args) {
        System.out.println("--- Inicio de la prueba del Patrón Singleton ---");

        // Intentamos obtener la instancia varias veces
        System.out.println("1. Solicitando primera referencia a la instancia...");
        Singleton s1 = Singleton.obtenerInstancia();
        
        System.out.println("2. Solicitando segunda referencia a la instancia...");
        Singleton s2 = Singleton.obtenerInstancia();

        // Comprobamos que ambas variables apuntan al mismo objeto en memoria
        System.out.println("\n3. Verificando identidad de objetos:");
        if (s1 == s2) {
            System.out.println("   [ÉXITO] s1 y s2 apuntan al MISMO objeto.");
            System.out.println("   Referencia s1: " + s1);
            System.out.println("   Referencia s2: " + s2);
        } else {
            System.out.println("   [ERROR] s1 y s2 son objetos DIFERENTES.");
        }

        // Usamos el método de la instancia
        System.out.println("\n4. Ejecutando método de la instancia:");
        s1.mostrarMensaje();
        
        System.out.println("--- Fin de la prueba ---");
    }
}
