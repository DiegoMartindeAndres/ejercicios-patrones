# Patrón Singleton (Instancia Única)

Este directorio contiene un ejemplo de implementación del **Patrón de Diseño Singleton** en Java.

## ¿Qué es el Singleton?

El patrón Singleton es un patrón de creación que garantiza que una clase tenga **una única instancia** y proporciona un punto de acceso global a ella.

## Contenido del Paquete `es.uva.poo.singleton`

A continuación se describen los ficheros incluidos en este ejemplo:

1.  **`Singleton.java`**: La clase que implementa el patrón.
    *   Tiene un **constructor privado** para impedir la creación de objetos con `new` desde fuera.
    *   Mantiene una **referencia estática privada** a la única instancia.
    *   Ofrece un método estático público `obtenerInstancia()` que crea la instancia si no existe y la devuelve.

2.  **`PruebaSingleton.java`**: Una clase con un método `main` para probar el patrón.
    *   Demuestra cómo obtener la instancia.
    *   Verifica que múltiples llamadas devuelven exactamente el mismo objeto.

## Cómo compilar y ejecutar

Desde la carpeta raíz `code`, puedes compilar y ejecutar este ejemplo usando la línea de comandos.

### 1. Compilar
```bash
javac es/uva/poo/singleton/*.java
```

### 2. Ejecutar
```bash
java es.uva.poo.singleton.PruebaSingleton
```

Deberías ver una salida que confirma que solo se inicializa el objeto una vez y que ambas referencias son idénticas.
