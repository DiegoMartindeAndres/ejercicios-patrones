package es.uva.poo.templatemethod;

/**
 * Demo mínima para ver el flujo del Template Method.
 *
 * No es necesario ejecutar nada para la práctica, pero sirve como cliente
 * que trabaja contra la clase base ({@link MineriaDatos}) sin conocer detalles
 * internos del algoritmo.
 */
public class Demo {

    public static void main(String[] args) {
        MineriaDatos mineriaCSV = new MineriaDatosCSV("datos/empleados.csv");
        MineriaDatos mineriaDOC = new MineriaDatosDOC("docs/informe.doc");
        MineriaDatos mineriaPDF = new MineriaDatosPDF("docs/resumen.pdf");

        System.out.println("=== CSV ===");
        mineriaCSV.minar();

        System.out.println("\n=== DOC ===");
        mineriaDOC.minar();

        System.out.println("\n=== PDF ===");
        mineriaPDF.minar();
    }
}
