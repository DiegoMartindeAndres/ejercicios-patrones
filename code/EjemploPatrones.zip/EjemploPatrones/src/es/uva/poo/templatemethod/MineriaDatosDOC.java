package es.uva.poo.templatemethod;

import java.util.Arrays;
import java.util.List;

/**
 * Implementación concreta para archivos DOC.
 *
 * Nota: es un ejemplo educativo; no hay lectura real de formato DOC.
 */
public class MineriaDatosDOC extends MineriaDatos {

    public MineriaDatosDOC(String rutaArchivo) {
        super(rutaArchivo);
    }

    @Override
    protected String extraerDatosBrutos() {
        // Simulación de texto extraído de un documento.
        return "INFORME TRIMESTRAL\nVentas: 120\nGastos: 75\nBeneficio: 45";
    }

    @Override
    protected List<String> parsearDatos(String datosBrutos) {
        // En este ejemplo tratamos cada línea como un 'dato'.
        return Arrays.asList(datosBrutos.split("\\R"));
    }
}
