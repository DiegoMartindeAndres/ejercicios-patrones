package es.uva.poo.templatemethod;

import java.util.ArrayList;
import java.util.List;

/**
 * Implementación concreta para archivos CSV.
 *
 * Aquí se implementan los pasos abstractos del método plantilla:
 * - {@link #extraerDatosBrutos()}
 * - {@link #parsearDatos(String)}
 */
public class MineriaDatosCSV extends MineriaDatos {

    public MineriaDatosCSV(String rutaArchivo) {
        super(rutaArchivo);
    }

    @Override
    protected String extraerDatosBrutos() {
        // Simulación: en un caso real leeríamos el fichero CSV.
        return "nombre,edad\nAna,20\nLuis,22\nMarta,21";
    }

    @Override
    protected List<String> parsearDatos(String datosBrutos) {
        // Parseo simple: devolvemos cada fila (excepto cabecera) como un String.
        String[] lineas = datosBrutos.split("\\R");
        List<String> filas = new ArrayList<>();
        for (int i = 1; i < lineas.length; i++) {
            filas.add(lineas[i]);
        }
        return filas;
    }

    @Override
    protected void antesDeAnalizar(List<String> datos) {
        // Ejemplo de gancho: avisar antes del análisis.
        System.out.println("[CSV] Preparando datos antes del análisis...");
    }
}
