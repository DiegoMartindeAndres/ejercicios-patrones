package es.uva.poo.templatemethod;

import java.util.Arrays;
import java.util.List;

/**
 * Implementación concreta para archivos PDF.
 *
 * Para mostrar que el patrón permite variar pasos opcionales, este ejemplo
 * decide saltarse el análisis (hook {@link #debeAnalizar()}).
 */
public class MineriaDatosPDF extends MineriaDatos {

    public MineriaDatosPDF(String rutaArchivo) {
        super(rutaArchivo);
    }

    @Override
    protected String extraerDatosBrutos() {
        // Simulación: un PDF suele tener extracción más compleja.
        return "PDF: resumen ejecutivo | KPIs | conclusiones";
    }

    @Override
    protected List<String> parsearDatos(String datosBrutos) {
        // Parseo simple: dividimos por el separador '|'.
        return Arrays.asList(datosBrutos.split("\\s*\\|\\s*"));
    }

    @Override
    protected boolean debeAnalizar() {
        // Ejemplo didáctico: para PDF, sólo extraemos y reportamos.
        return false;
    }

    @Override
    protected void enviarInforme(List<String> datos) {
        // Sobrescribimos un paso con implementación por defecto.
        System.out.println("Generando informe (PDF, modo resumen)...");
        System.out.println("- Archivo: " + getRutaArchivo());
        System.out.println("- Secciones detectadas: " + datos.size());
    }
}
