# Template Method (Método plantilla)

Ejemplo en Java del patrón **Template Method**, con nombres en español y paquete:

- `es.uva.poo.templatemethod`

Basado en el caso típico descrito en refactoring.guru: una aplicación de **minería de datos** que procesa documentos corporativos en distintos formatos (CSV, DOC, PDF).

## Idea clave del patrón

La clase base define el **esqueleto** del algoritmo en un método *plantilla* y deja a las subclases implementar o personalizar ciertos pasos.

En este ejemplo:

- La clase base `MineriaDatos` define el flujo general en `minar()`.
- Las subclases (`MineriaDatosCSV`, `MineriaDatosDOC`, `MineriaDatosPDF`) implementan los pasos que cambian según el formato.

## Diagrama de clases (Mermaid)

```mermaid
classDiagram
direction TB

class MineriaDatos {
  -String rutaArchivo
  +String getRutaArchivo()
  +void minar()

  #void abrirArchivo()
  #String extraerDatosBrutos()
  #List~String~ parsearDatos(String datosBrutos)

  #void analizarDatos(List~String~ datos)
  #void antesDeAnalizar(List~String~ datos)
  #void despuesDeAnalizar(List~String~ datos)
  #boolean debeAnalizar()

  #void enviarInforme(List~String~ datos)
  #void cerrarArchivo()
}
<<abstract>> MineriaDatos

class MineriaDatosCSV {
  +MineriaDatosCSV(String rutaArchivo)
  #String extraerDatosBrutos()
  #List~String~ parsearDatos(String datosBrutos)
  #void antesDeAnalizar(List~String~ datos)
}

class MineriaDatosDOC {
  +MineriaDatosDOC(String rutaArchivo)
  #String extraerDatosBrutos()
  #List~String~ parsearDatos(String datosBrutos)
}

class MineriaDatosPDF {
  +MineriaDatosPDF(String rutaArchivo)
  #String extraerDatosBrutos()
  #List~String~ parsearDatos(String datosBrutos)
  #boolean debeAnalizar()
  #void enviarInforme(List~String~ datos)
}

class Demo {
  +static void main(String[] args)
}

MineriaDatos <|-- MineriaDatosCSV
MineriaDatos <|-- MineriaDatosDOC
MineriaDatos <|-- MineriaDatosPDF
Demo ..> MineriaDatos : usa
```

## Archivos

- `MineriaDatos.java`
  - Clase abstracta.
  - Contiene el método plantilla `minar()` (marcado como `final`).
  - Define pasos abstractos y pasos con implementación por defecto.
  - Incluye *ganchos* (hooks): `debeAnalizar()`, `antesDeAnalizar(...)`, `despuesDeAnalizar(...)`.

- `MineriaDatosCSV.java`
  - Subclase concreta para CSV.
  - Implementa extracción y parseo.
  - Sobrescribe un gancho para mostrar personalización antes del análisis.

- `MineriaDatosDOC.java`
  - Subclase concreta para DOC.
  - Implementa extracción y parseo (simulados).

- `MineriaDatosPDF.java`
  - Subclase concreta para PDF.
  - Implementa extracción y parseo (simulados).
  - Usa el gancho `debeAnalizar()` para **saltar** el análisis y sobrescribe `enviarInforme(...)`.

- `Demo.java`
  - Cliente mínimo que instancia varias implementaciones y llama a `minar()`.
  - Sirve para entender el flujo; no es necesario ejecutarlo para la práctica.

## Orden recomendado para crear/entender el ejemplo

1. `MineriaDatos.java`
   - Definir el método plantilla `minar()`.
   - Declarar pasos abstractos y pasos por defecto.
   - Añadir ganchos (hooks).
2. `MineriaDatosCSV.java`
   - Implementar pasos abstractos para un formato concreto.
3. `MineriaDatosDOC.java`
   - Implementar una segunda variante.
4. `MineriaDatosPDF.java`
   - Mostrar cómo una subclase puede sobrescribir pasos opcionales / ganchos.
5. `Demo.java`
   - Crear un cliente que use la clase base.
