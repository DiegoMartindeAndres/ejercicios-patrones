package es.uva.poo.templatemethod;

import java.util.List;

/**
 * Ejemplo del patrón Template Method (Método plantilla).
 *
 * La clase base define el "esqueleto" del algoritmo en el método plantilla {@link #minar()},
 * dejando a las subclases la implementación de ciertos pasos (métodos abstractos) y
 * permitiendo opcionalmente personalizar otros pasos (métodos con implementación por defecto).
 *
 * Contexto del ejemplo (basado en refactoring.guru):
 * una aplicación de minería de datos que procesa documentos corporativos en distintos formatos
 * (CSV, DOC, PDF) para extraer información y generar un informe.
 */
public abstract class MineriaDatos {

    private final String rutaArchivo;

    /**
     * @param rutaArchivo Ruta lógica del archivo a procesar.
     */
    protected MineriaDatos(String rutaArchivo) {
        this.rutaArchivo = rutaArchivo;
    }

    public String getRutaArchivo() {
        return rutaArchivo;
    }

    /**
     * Método plantilla.
     *
     * Define el flujo general del algoritmo. Se marca como {@code final} para evitar que
     * las subclases cambien la estructura (la esencia del patrón).
     */
    public final void minar() {
        abrirArchivo();

        String datosBrutos = extraerDatosBrutos();
        List<String> datos = parsearDatos(datosBrutos);

        // Gancho (hook): permite desactivar/activar una parte del algoritmo.
        if (debeAnalizar()) {
            antesDeAnalizar(datos);
            analizarDatos(datos);
            despuesDeAnalizar(datos);
        }

        enviarInforme(datos);
        cerrarArchivo();
    }

    /**
     * Paso con implementación por defecto.
     * Subclases pueden sobrescribirlo si necesitan una apertura/carga distinta.
     */
    protected void abrirArchivo() {
        System.out.println("Abriendo archivo: " + rutaArchivo);
    }

    /**
     * Paso abstracto: cada formato extrae los datos de manera diferente.
     */
    protected abstract String extraerDatosBrutos();

    /**
     * Paso abstracto: cada formato requiere un parseo distinto.
     */
    protected abstract List<String> parsearDatos(String datosBrutos);

    /**
     * Paso con implementación compartida.
     * Aquí simulamos el análisis: en un caso real podría haber IA, estadísticas, etc.
     */
    protected void analizarDatos(List<String> datos) {
        System.out.println("Analizando " + datos.size() + " elementos...");
    }

    /**
     * Gancho (hook) vacío: punto de extensión antes del análisis.
     */
    protected void antesDeAnalizar(List<String> datos) {
        // Por defecto no hace nada.
    }

    /**
     * Gancho (hook) vacío: punto de extensión después del análisis.
     */
    protected void despuesDeAnalizar(List<String> datos) {
        // Por defecto no hace nada.
    }

    /**
     * Gancho (hook) con valor por defecto.
     * Una subclase puede devolver {@code false} para saltarse el análisis.
     */
    protected boolean debeAnalizar() {
        return true;
    }

    /**
     * Paso con implementación compartida.
     * Genera un informe sencillo a partir de lo procesado.
     */
    protected void enviarInforme(List<String> datos) {
        System.out.println("Generando informe...");
        System.out.println("- Archivo: " + rutaArchivo);
        System.out.println("- Elementos procesados: " + datos.size());
    }

    /**
     * Paso con implementación por defecto.
     */
    protected void cerrarArchivo() {
        System.out.println("Cerrando archivo: " + rutaArchivo);
    }
}
