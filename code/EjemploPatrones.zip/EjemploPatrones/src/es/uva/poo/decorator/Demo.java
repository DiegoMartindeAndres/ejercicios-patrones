package es.uva.poo.decorator;

/**
 * Demo / Punto de entrada.
 *
 * <p>Ejemplo del patrón Decorator: vamos envolviendo una {@link FuenteDatos}
 * con decoradores (compresión y cifrado) sin cambiar la clase del fichero.</p>
 */
public class Demo {

    public static void main(String[] args) {
        String ruta = "decorator_demo.txt";
        String textoOriginal = "Hola.\nEste es un ejemplo del patrón Decorator en Java.";

        // Componente concreto: persistencia en fichero.
        FuenteDatos fuenteFichero = new FuenteDatosArchivo(ruta);

        // Decoradores: primero comprimimos y luego ciframos.
        // El orden importa: (comprimir -> cifrar) no es lo mismo que (cifrar -> comprimir).
        FuenteDatos fuenteDecorada = new DecoradorCifrado(
                new DecoradorCompresion(fuenteFichero),
                "clave-secreta"
        );

        // 1) Escribimos datos usando la fuente decorada.
        fuenteDecorada.escribirDatos(textoOriginal);

        // 2) Para demostrar el efecto, leemos desde el fichero SIN decoradores.
        String crudoEnFichero = fuenteFichero.leerDatos();

        // 3) Leemos con decoradores (se deshacen compresión + cifrado).
        String recuperado = fuenteDecorada.leerDatos();

        System.out.println("--- Texto original ---");
        System.out.println(textoOriginal);

        System.out.println("\n--- Contenido crudo en fichero (comprimido+cifrado) ---");
        System.out.println(crudoEnFichero);

        System.out.println("\n--- Texto recuperado (descifrado+descomprimido) ---");
        System.out.println(recuperado);

        System.out.println("\nFichero usado: " + ruta);
    }
}
