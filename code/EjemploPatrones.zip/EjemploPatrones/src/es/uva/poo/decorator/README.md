# Decorator (Java) — ejemplo en Español

Paquete: `es.uva.poo.decorator`

Este ejemplo está basado en la explicación y estructura del patrón **Decorator** de Refactoring.Guru:
https://refactoring.guru/es/design-patterns/decorator

## Idea del patrón

**Decorator** permite añadir responsabilidades (comportamientos) a un objeto **en tiempo de ejecución** envolviéndolo en otros objetos (decoradores) que implementan la misma interfaz.

En este ejemplo, una fuente de datos básica guarda/lee texto desde un fichero. Encima añadimos dos capacidades opcionales:

- **Compresión** (antes de guardar / después de leer)
- **Cifrado** (antes de guardar / después de leer)

## Ficheros

- `FuenteDatos.java`
  - Interfaz *Componente*. Define `escribirDatos()` y `leerDatos()`.

- `FuenteDatosArchivo.java`
  - *Componente concreto*. Implementa la lectura/escritura real en un fichero.

- `DecoradorFuenteDatos.java`
  - *Decorador base*. Implementa `FuenteDatos` y delega en otra `FuenteDatos` interna.

- `DecoradorCompresion.java`
  - *Decorador concreto*. Comprime al escribir y descomprime al leer.

- `DecoradorCifrado.java`
  - *Decorador concreto*. Cifra al escribir y descifra al leer.
  - Nota: el cifrado es XOR+Base64 (didáctico, no seguro).

- `Demo.java`
  - Programa de ejemplo (main). Monta la cadena de decoradores y muestra:
    - el texto original
    - lo que queda realmente guardado en el fichero (comprimido+cifrado)
    - el texto recuperado (descifrado+descomprimido)

## Diagrama de clases (Mermaid)

```mermaid
classDiagram


class FuenteDatos {
  <<interface>>
  +escribirDatos(String datos)
  +leerDatos() String
}

class FuenteDatosArchivo {
  -fichero File
  +FuenteDatosArchivo(String ruta)
  +escribirDatos(String datos)
  +leerDatos() String
  +getRuta() String
}

class DecoradorFuenteDatos {
  <<abstract>>
  #envoltorio FuenteDatos
  #DecoradorFuenteDatos(FuenteDatos envoltorio)
  +escribirDatos(String datos)
  +leerDatos() String
}

class DecoradorCompresion {
  +DecoradorCompresion(FuenteDatos envoltorio)
  +escribirDatos(String datos)
  +leerDatos() String
}

class DecoradorCifrado {
  -clave byte[]
  +DecoradorCifrado(FuenteDatos envoltorio, String clave)
  +escribirDatos(String datos)
  +leerDatos() String
}

class Demo {
  +main(String[] args)$
}

FuenteDatos <|.. FuenteDatosArchivo
FuenteDatos <|.. DecoradorFuenteDatos

DecoradorFuenteDatos <|-- DecoradorCompresion
DecoradorFuenteDatos <|-- DecoradorCifrado

DecoradorFuenteDatos o--> FuenteDatos : envoltorio
Demo ..> FuenteDatos : usa / compone
```

## Orden recomendado de creación (para entenderlo)

1. `FuenteDatos` (interfaz)
2. `FuenteDatosArchivo` (componente concreto)
3. `DecoradorFuenteDatos` (decorador base)
4. `DecoradorCompresion` (decorador concreto)
5. `DecoradorCifrado` (decorador concreto)
6. `Demo` (cliente)

## Cómo ejecutar (desde la carpeta `code/`)

Compilar:

```bash
javac es/uva/poo/decorator/*.java
```

Ejecutar:

```bash
java es.uva.poo.decorator.Demo
```

Se creará un fichero `decorator_demo.txt` en el directorio desde el que ejecutes el programa.
