package es.uva.poo.decorator;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

/**
 * Decorador concreto: Cifrado.
 *
 * <p>En el ejemplo original de Refactoring.Guru se muestra un decorador de cifrado.
 * Aquí implementamos un cifrado muy sencillo (XOR + Base64) para fines didácticos.
 * No es criptográficamente seguro.</p>
 */
public class DecoradorCifrado extends DecoradorFuenteDatos {

    private final byte[] clave;

    /**
     * @param envoltorio Fuente de datos a decorar.
     * @param clave Texto de clave (se reutiliza de forma circular).
     */
    public DecoradorCifrado(FuenteDatos envoltorio, String clave) {
        super(envoltorio);
        if (clave == null || clave.isEmpty()) {
            throw new IllegalArgumentException("La clave de cifrado no puede ser nula o vacía");
        }
        this.clave = clave.getBytes(StandardCharsets.UTF_8);
    }

    @Override
    public void escribirDatos(String datos) {
        String cifrado = cifrar(datos != null ? datos : "");
        super.escribirDatos(cifrado);
    }

    @Override
    public String leerDatos() {
        String almacenado = super.leerDatos();
        if (almacenado == null || almacenado.isEmpty()) {
            return "";
        }
        return descifrar(almacenado);
    }

    private String cifrar(String plano) {
        byte[] bytesPlano = plano.getBytes(StandardCharsets.UTF_8);
        byte[] bytesCifrados = aplicarXor(bytesPlano);
        return Base64.getEncoder().encodeToString(bytesCifrados);
    }

    private String descifrar(String base64) {
        byte[] bytesCifrados = Base64.getDecoder().decode(base64);
        byte[] bytesPlano = aplicarXor(bytesCifrados);
        return new String(bytesPlano, StandardCharsets.UTF_8);
    }

    private byte[] aplicarXor(byte[] datos) {
        byte[] resultado = new byte[datos.length];
        for (int i = 0; i < datos.length; i++) {
            resultado[i] = (byte) (datos[i] ^ clave[i % clave.length]);
        }
        return resultado;
    }
}
