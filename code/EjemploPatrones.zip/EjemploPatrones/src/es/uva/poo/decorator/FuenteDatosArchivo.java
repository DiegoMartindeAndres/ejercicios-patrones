package es.uva.poo.decorator;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;

/**
 * Componente concreto.
 *
 * <p>Implementación básica de {@link FuenteDatos} que escribe/lee en un fichero.</p>
 */
public class FuenteDatosArchivo implements FuenteDatos {

    private final File fichero;

    /**
     * @param ruta Ruta al fichero donde se guardarán los datos.
     */
    public FuenteDatosArchivo(String ruta) {
        this.fichero = new File(ruta);
    }

    @Override
    public void escribirDatos(String datos) {
        // Sobrescribimos el fichero entero por simplicidad.
        try (BufferedWriter writer = new BufferedWriter(
                new OutputStreamWriter(new FileOutputStream(fichero), StandardCharsets.UTF_8))) {
            writer.write(datos != null ? datos : "");
        } catch (IOException e) {
            throw new RuntimeException("Error escribiendo en el fichero: " + fichero.getAbsolutePath(), e);
        }
    }

    @Override
    public String leerDatos() {
        if (!fichero.exists()) {
            return "";
        }

        StringBuilder contenido = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(new FileInputStream(fichero), StandardCharsets.UTF_8))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                if (contenido.length() > 0) {
                    contenido.append(System.lineSeparator());
                }
                contenido.append(linea);
            }
            return contenido.toString();
        } catch (IOException e) {
            throw new RuntimeException("Error leyendo el fichero: " + fichero.getAbsolutePath(), e);
        }
    }

    /**
     * @return Ruta del fichero (útil para trazas en la demo).
     */
    public String getRuta() {
        return fichero.getPath();
    }
}
