package es.uva.poo.decorator;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.zip.DataFormatException;
import java.util.zip.Deflater;
import java.util.zip.Inflater;

/**
 * Decorador concreto: Compresión.
 *
 * <p>Comprime los datos antes de escribirlos y los descomprime al leer.</p>
 */
public class DecoradorCompresion extends DecoradorFuenteDatos {

    /**
     * @param envoltorio Fuente de datos a decorar.
     */
    public DecoradorCompresion(FuenteDatos envoltorio) {
        super(envoltorio);
    }

    @Override
    public void escribirDatos(String datos) {
        String comprimido = comprimir(datos != null ? datos : "");
        super.escribirDatos(comprimido);
    }

    @Override
    public String leerDatos() {
        String almacenado = super.leerDatos();
        if (almacenado == null || almacenado.isEmpty()) {
            return "";
        }
        return descomprimir(almacenado);
    }

    /**
     * Comprime texto (UTF-8) y lo devuelve como Base64 para poder guardarlo como String.
     */
    private String comprimir(String texto) {
        byte[] entrada = texto.getBytes(StandardCharsets.UTF_8);

        Deflater deflater = new Deflater(Deflater.DEFAULT_COMPRESSION);
        deflater.setInput(entrada);
        deflater.finish();

        byte[] buffer = new byte[1024];
        ByteArrayOutputStream salida = new ByteArrayOutputStream();
        while (!deflater.finished()) {
            int cuenta = deflater.deflate(buffer);
            salida.write(buffer, 0, cuenta);
        }
        deflater.end();

        return Base64.getEncoder().encodeToString(salida.toByteArray());
    }

    /**
     * Descomprime Base64 (deflate) y devuelve texto (UTF-8).
     */
    private String descomprimir(String base64) {
        byte[] entrada = Base64.getDecoder().decode(base64);

        Inflater inflater = new Inflater();
        inflater.setInput(entrada);

        byte[] buffer = new byte[1024];
        ByteArrayOutputStream salida = new ByteArrayOutputStream();
        try {
            while (!inflater.finished()) {
                int cuenta = inflater.inflate(buffer);
                // Si no hay progreso y no está finished, suele ser datos corruptos.
                if (cuenta == 0 && inflater.needsInput()) {
                    break;
                }
                salida.write(buffer, 0, cuenta);
            }
        } catch (DataFormatException e) {
            throw new RuntimeException("Datos comprimidos corruptos o formato inválido", e);
        } finally {
            inflater.end();
        }

        return new String(salida.toByteArray(), StandardCharsets.UTF_8);
    }
}
