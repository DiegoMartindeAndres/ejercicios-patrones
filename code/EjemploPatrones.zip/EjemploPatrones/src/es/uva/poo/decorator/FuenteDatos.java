package es.uva.poo.decorator;

/**
 * Interfaz Componente.
 *
 * <p>Define el contrato que deben cumplir tanto los componentes concretos como
 * los decoradores. El objetivo es que el cliente pueda tratar a ambos por igual.</p>
 *
 * <p>Ejemplo inspirado en Refactoring.Guru (patrón Decorator):
 * https://refactoring.guru/es/design-patterns/decorator</p>
 */
public interface FuenteDatos {

    /**
     * Escribe (persiste) los datos.
     *
     * @param datos Información a almacenar.
     */
    void escribirDatos(String datos);

    /**
     * Lee (recupera) los datos.
     *
     * @return Información almacenada (cadena vacía si no hay nada).
     */
    String leerDatos();
}
