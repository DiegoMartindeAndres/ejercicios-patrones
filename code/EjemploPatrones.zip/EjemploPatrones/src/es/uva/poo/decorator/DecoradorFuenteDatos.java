package es.uva.poo.decorator;

/**
 * Decorador base.
 *
 * <p>Implementa {@link FuenteDatos} y delega en otra {@link FuenteDatos} interna.
 * Las subclases pueden añadir comportamiento antes/después de delegar.</p>
 */
public abstract class DecoradorFuenteDatos implements FuenteDatos {

    protected final FuenteDatos envoltorio;

    /**
     * @param envoltorio Componente que se está decorando.
     */
    protected DecoradorFuenteDatos(FuenteDatos envoltorio) {
        this.envoltorio = envoltorio;
    }

    @Override
    public void escribirDatos(String datos) {
        envoltorio.escribirDatos(datos);
    }

    @Override
    public String leerDatos() {
        return envoltorio.leerDatos();
    }
}
