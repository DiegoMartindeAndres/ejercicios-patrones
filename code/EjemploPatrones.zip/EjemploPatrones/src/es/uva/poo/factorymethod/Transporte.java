package es.uva.poo.factorymethod;

/**
 * Interfaz Transporte.
 * 
 * <p>Define la interfaz común para todos los productos que pueden ser creados
 * por la factoría. En este caso, representa un medio de transporte.</p>
 * 
 * @author Diego 
 */
public interface Transporte {
    /**
     * Realiza la entrega de la mercancía.
     */
    void entregar();
}
