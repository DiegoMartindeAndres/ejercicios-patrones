package es.uva.poo.factorymethod;

/**
 * Clase concreta Camion.
 * 
 * <p>Implementa la interfaz Transporte para representar un transporte por carretera.
 * Esta clase es una de las implementaciones concretas que pueden ser creadas.</p>
 * 
 * @author Diego 
 */
public class Camion implements Transporte {

    @Override
    public void entregar() {
        System.out.println("Entrega por tierra en una caja.");
    }
}
