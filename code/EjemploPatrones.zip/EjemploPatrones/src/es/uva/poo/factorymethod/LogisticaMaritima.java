package es.uva.poo.factorymethod;

/**
 * Creador concreto LogisticaMaritima.
 * 
 * <p>Sobrescribe el método factory para crear y devolver un objeto Barco.</p>
 * 
 * @author Diego 
 */
public class LogisticaMaritima extends Logistica {

    @Override
    public Transporte crearTransporte() {
        return new Barco();
    }
}
