# Patrón Factory Method - Ejemplo en Java

Este directorio contiene un ejemplo de implementación del patrón de diseño **Factory Method** en Java.

## Descripción del Ejemplo
El ejemplo simula una aplicación de logística. La clase `Logistica` (Creadora) decide qué medio de transporte utilizar, pero delega la creación del objeto `Transporte` (Producto) a sus subclases.

- **LogisticaTerrestre**: Crea un `Camion`.
- **LogisticaMaritima**: Crea un `Barco`.

## Diagrama de clases

```mermaid
classDiagram


class Logistica {
	<<abstract>>
	+crearTransporte() Transporte
	+planificarEntrega() void
}

class LogisticaTerrestre {
	+crearTransporte() Transporte
}

class LogisticaMaritima {
	+crearTransporte() Transporte
}

class Transporte {
	<<interface>>
	+entregar() void
}

class Camion {
	+entregar() void
}

class Barco {
	+entregar() void
}

class Main {
	+main(String[]) void
}

Logistica <|-- LogisticaTerrestre
Logistica <|-- LogisticaMaritima

Transporte <|.. Camion
Transporte <|.. Barco

Logistica ..> Transporte : crea/usa
Main ..> Logistica : usa
Main ..> LogisticaTerrestre : instancia
Main ..> LogisticaMaritima : instancia
```

## Estructura de Ficheros

A continuación se describen los ficheros en el orden sugerido de creación/lectura para entender el patrón:

1.  **Transporte.java** (Producto): Interfaz común para todos los objetos que pueden ser producidos.
2.  **Camion.java** (Producto Concreto): Implementación de `Transporte` para entrega por tierra.
3.  **Barco.java** (Producto Concreto): Implementación de `Transporte` para entrega marítima.
4.  **Logistica.java** (Creador): Clase abstracta que declara el método fábrica `crearTransporte()`. También contiene la lógica de negocio (`planificarEntrega`) que utiliza el producto.
5.  **LogisticaTerrestre.java** (Creador Concreto): Sobrescribe el método fábrica para devolver un `Camion`.
6.  **LogisticaMaritima.java** (Creador Concreto): Sobrescribe el método fábrica para devolver un `Barco`.
7.  **Main.java** (Cliente): Código cliente que utiliza las clases creadoras.

## Ejecución

Para compilar y ejecutar el ejemplo desde la raíz del código fuente (`code/`):

```bash
javac es/uva/poo/factorymethod/*.java
java es.uva.poo.factorymethod.Main
```

Salida esperada:

```text
--- Logística Terrestre ---
Entrega por tierra en una caja.

--- Logística Marítima ---
Entrega por mar en un contenedor.
```
