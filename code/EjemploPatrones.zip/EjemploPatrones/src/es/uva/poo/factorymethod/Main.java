package es.uva.poo.factorymethod;

/**
 * Clase principal Main.
 * 
 * <p>Demuestra el uso del patrón Factory Method. El cliente trabaja con la clase
 * creadora abstracta (Logistica) y la interfaz de producto (Transporte), sin
 * acoplarse a las clases concretas.</p>
 * 
 * @author Diego 
 */
public class Main {
    
    /**
     * Método principal de ejecución.
     * @param args Argumentos de línea de comandos (no utilizados).
     */
    public static void main(String[] args) {
        System.out.println("--- Logística Terrestre ---");
        Logistica logistica1 = new LogisticaTerrestre();
        logistica1.planificarEntrega();
        
        System.out.println("\n--- Logística Marítima ---");
        Logistica logistica2 = new LogisticaMaritima();
        logistica2.planificarEntrega();
    }
}
