package es.uva.poo.factorymethod;

/**
 * Creador concreto LogisticaTerrestre.
 * 
 * <p>Sobrescribe el método factory para crear y devolver un objeto Camion.</p>
 * 
 * @author Diego 
 */
public class LogisticaTerrestre extends Logistica {

    @Override
    public Transporte crearTransporte() {
        return new Camion();
    }
}
