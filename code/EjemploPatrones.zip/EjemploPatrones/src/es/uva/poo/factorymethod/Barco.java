package es.uva.poo.factorymethod;

/**
 * Clase concreta Barco.
 * 
 * <p>Implementa la interfaz Transporte para representar un transporte marítimo.
 * Esta clase es otra de las implementaciones concretas disponibles.</p>
 * 
 * @author Diego 
 */
public class Barco implements Transporte {

    @Override
    public void entregar() {
        System.out.println("Entrega por mar en un contenedor.");
    }
}
