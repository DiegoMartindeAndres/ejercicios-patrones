package es.uva.poo.factorymethod;

/**
 * Clase creadora abstracta Logistica.
 * 
 * <p>Esta clase declara el método de fábrica que debe devolver un objeto de la
 * clase Transporte. Las subclases de Logística suelen proporcionar la
 * implementación de este método.</p>
 * 
 * @author Diego 
 */
public abstract class Logistica {

    /**
     * El método de fábrica (Factory Method).
     * 
     * @return Una instancia de un objeto que implementa la interfaz Transporte.
     */
    public abstract Transporte crearTransporte();

    /**
     * Método que contiene la lógica de negocio principal y que depende de los
     * objetos producto devueltos por el factory method.
     */
    public void planificarEntrega() {
        // Llama al factory method para crear un objeto producto.
        Transporte transporte = crearTransporte();
        
        // Ahora usa el producto.
        transporte.entregar();
    }
}
