package es.uva.poo.abstractfactory;

/**
 * Interfaz para el producto "Mesilla".
 * Todos los tipos de mesillas deben implementar esta interfaz.
 */
public interface Mesilla {
    /**
     * Método común para todas las mesillas.
     */
    void ponerCosasEncima();
}
