package es.uva.poo.abstractfactory;

/**
 * Fábrica Concreta para muebles Modernos.
 * Crea familias de productos modernos.
 */
public class FabricaMueblesModernos implements FabricaMuebles {

    @Override
    public Silla crearSilla() {
        return new SillaModerna();
    }

    @Override
    public Sofa crearSofa() {
        return new SofaModerno();
    }

    @Override
    public Mesilla crearMesilla() {
        return new MesillaModerna();
    }
}
