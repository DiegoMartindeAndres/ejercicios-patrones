package es.uva.poo.abstractfactory;

/**
 * Fábrica Concreta para muebles ArtDeco.
 * Crea familias de productos ArtDeco.
 */
public class FabricaMueblesArtDeco implements FabricaMuebles {

    @Override
    public Silla crearSilla() {
        return new SillaArtDeco();
    }

    @Override
    public Sofa crearSofa() {
        return new SofaArtDeco();
    }

    @Override
    public Mesilla crearMesilla() {
        return new MesillaArtDeco();
    }
}
