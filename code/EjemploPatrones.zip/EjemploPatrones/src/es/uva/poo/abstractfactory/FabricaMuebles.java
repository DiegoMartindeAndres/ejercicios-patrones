package es.uva.poo.abstractfactory;

/**
 * Interfaz de la Fábrica Abstracta.
 * Declara métodos para crear cada tipo de producto abstracto (Silla, Sofá, Mesilla).
 */
public interface FabricaMuebles {
    Silla crearSilla();
    Sofa crearSofa();
    Mesilla crearMesilla();
}
