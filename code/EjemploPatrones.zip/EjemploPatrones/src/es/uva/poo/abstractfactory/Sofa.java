package es.uva.poo.abstractfactory;

/**
 * Interfaz para el producto "Sofá".
 * Todos los tipos de sofás deben implementar esta interfaz.
 */
public interface Sofa {
    /**
     * Método común para todos los sofás.
     */
    void tumbarse();
}
