package es.uva.poo.abstractfactory;

/**
 * Implementación concreta de una Mesilla en estilo ArtDeco.
 */
public class MesillaArtDeco implements Mesilla {

    @Override
    public void ponerCosasEncima() {
        System.out.println("Colocas una copa en la Mesilla ArtDeco con incrustaciones.");
    }
}
