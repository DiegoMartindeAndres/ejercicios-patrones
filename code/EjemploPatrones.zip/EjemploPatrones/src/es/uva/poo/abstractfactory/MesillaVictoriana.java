package es.uva.poo.abstractfactory;

/**
 * Implementación concreta de una Mesilla en estilo Victoriano.
 */
public class MesillaVictoriana implements Mesilla {

    @Override
    public void ponerCosasEncima() {
        System.out.println("Dejas un libro antiguo en la Mesilla Victoriana de caoba.");
    }
}
