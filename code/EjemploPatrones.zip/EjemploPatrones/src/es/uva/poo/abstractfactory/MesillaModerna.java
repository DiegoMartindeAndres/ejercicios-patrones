package es.uva.poo.abstractfactory;

/**
 * Implementación concreta de una Mesilla en estilo Moderno.
 */
public class MesillaModerna implements Mesilla {

    @Override
    public void ponerCosasEncima() {
        System.out.println("Pones el café en la Mesilla Moderna de cristal.");
    }
}
