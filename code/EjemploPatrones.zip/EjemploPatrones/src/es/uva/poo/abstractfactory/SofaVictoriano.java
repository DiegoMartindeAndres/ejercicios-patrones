package es.uva.poo.abstractfactory;

/**
 * Implementación concreta de un Sofá en estilo Victoriano.
 */
public class SofaVictoriano implements Sofa {

    @Override
    public void tumbarse() {
        System.out.println("Te tumbas en un Sofá Victoriano. Es suave y clásico.");
    }
}
