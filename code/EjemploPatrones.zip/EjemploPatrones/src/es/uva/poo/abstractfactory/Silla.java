package es.uva.poo.abstractfactory;

/**
 * Interfaz para el producto "Silla".
 * Todos los tipos de sillas (Moderna, Victoriana, ArtDeco) deben implementar esta interfaz.
 */
public interface Silla {
    /**
     * Método común para todas las sillas.
     * Por ejemplo, todas las sillas tienen patas.
     */
    void tienePatas();

    /**
     * Otro método común.
     * Por ejemplo, sentarse en la silla.
     */
    void sentarse();
}
