package es.uva.poo.abstractfactory;

/**
 * Implementación concreta de un Sofá en estilo ArtDeco.
 */
public class SofaArtDeco implements Sofa {

    @Override
    public void tumbarse() {
        System.out.println("Te tumbas en un Sofá ArtDeco. Te sientes en los años 20.");
    }
}
