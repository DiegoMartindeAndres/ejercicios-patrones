package es.uva.poo.abstractfactory;

/**
 * Clase de Demostración (Main).
 * Configura la aplicación seleccionando una fábrica concreta y crea el Cliente.
 * Esta es la única parte del código que conoce las clases concretas.
 */
public class Demo {

    /**
     * Configura la aplicación para usar una fábrica específica.
     * En una aplicación real, esto se leería de configuración o variables de entorno.
     * @return Una instancia de Cliente configurada con la fábrica adecuada.
     */
    private static Cliente configurarAplicacion() {
        Cliente cliente;
        FabricaMuebles fabrica;

        // Simulación de configuración. Cambiar la cadena para probar diferentes fábricas.
        // Opciones: "MODERNO", "VICTORIANO", "ARTDECO"
        String estiloMuebles = "VICTORIANO"; 

        if (estiloMuebles.equalsIgnoreCase("MODERNO")) {
            fabrica = new FabricaMueblesModernos();
        } else if (estiloMuebles.equalsIgnoreCase("VICTORIANO")) {
            fabrica = new FabricaMueblesVictorianos();
        } else {
            fabrica = new FabricaMueblesArtDeco();
        }

        cliente = new Cliente(fabrica);
        return cliente;
    }

    public static void main(String[] args) {
        Cliente cliente = configurarAplicacion();
        cliente.usarMuebles();
    }
}
