package es.uva.poo.abstractfactory;

/**
 * Implementación concreta de una Silla en estilo Moderno.
 */
public class SillaModerna implements Silla {

    @Override
    public void tienePatas() {
        System.out.println("La Silla Moderna tiene patas minimalistas.");
    }

    @Override
    public void sentarse() {
        System.out.println("Te sientas en una Silla Moderna. Es muy ergonómica.");
    }
}
