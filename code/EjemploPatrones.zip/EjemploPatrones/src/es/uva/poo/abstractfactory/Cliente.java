package es.uva.poo.abstractfactory;

/**
 * Código Cliente.
 * Interactúa con las fábricas y productos a través de sus interfaces abstractas.
 * No conoce las clases de productos concretos (SillaVictoriana, etc.) ni las fábricas concretas.
 */
public class Cliente {
    private Silla silla;
    private Sofa sofa;
    private Mesilla mesilla;

    /**
     * El constructor recibe la fábrica abstracta.
     * @param fabrica La fábrica específica que creará los muebles de un estilo concreto.
     */
    public Cliente(FabricaMuebles fabrica) {
        this.silla = fabrica.crearSilla();
        this.sofa = fabrica.crearSofa();
        this.mesilla = fabrica.crearMesilla();
    }

    /**
     * Método de prueba para usar los muebles creados.
     */
    public void usarMuebles() {
        silla.tienePatas();
        silla.sentarse();
        sofa.tumbarse();
        mesilla.ponerCosasEncima();
    }
}
