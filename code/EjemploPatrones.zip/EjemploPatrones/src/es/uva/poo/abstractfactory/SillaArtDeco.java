package es.uva.poo.abstractfactory;

/**
 * Implementación concreta de una Silla en estilo ArtDeco.
 */
public class SillaArtDeco implements Silla {

    @Override
    public void tienePatas() {
        System.out.println("La Silla ArtDeco tiene patas geométricas.");
    }

    @Override
    public void sentarse() {
        System.out.println("Te sientas en una Silla ArtDeco. Muy elegante.");
    }
}
