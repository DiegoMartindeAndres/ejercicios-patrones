package es.uva.poo.abstractfactory;

/**
 * Implementación concreta de un Sofá en estilo Moderno.
 */
public class SofaModerno implements Sofa {

    @Override
    public void tumbarse() {
        System.out.println("Te tumbas en un Sofá Moderno. El diseño es limpio y simple.");
    }
}
