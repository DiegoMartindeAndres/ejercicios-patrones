# Patrón de Diseño Abstract Factory (Fábrica Abstracta)

Este ejemplo implementa el patrón **Abstract Factory** en Java, utilizando una familia de Muebles (Silla, Sofá, Mesilla) con variantes de estilo (Moderno, Victoriano, ArtDeco).

## Estructura del Código

El código se encuentra en el paquete `es.uva.poo.abstractfactory`.

### 1. Interfaces de Productos (Abstract Products)
Definen la funcionalidad común para cada tipo de mueble.
- `Silla.java`: Interfaz para sillas.
- `Sofa.java`: Interfaz para sofás.
- `Mesilla.java`: Interfaz para mesillas.

### 2. Implementaciones Concretas (Concrete Products)
Implementan las interfaces para cada variante de estilo.
- **Estilo Moderno**: `SillaModerna.java`, `SofaModerno.java`, `MesillaModerna.java`
- **Estilo Victoriano**: `SillaVictoriana.java`, `SofaVictoriano.java`, `MesillaVictoriana.java`
- **Estilo ArtDeco**: `SillaArtDeco.java`, `SofaArtDeco.java`, `MesillaArtDeco.java`

### 3. Fábrica Abstracta (Abstract Factory)
Declara los métodos de creación para todos los productos de la familia.
- `FabricaMuebles.java`: Interfaz que define `crearSilla()`, `crearSofa()`, `crearMesilla()`.

### 4. Fábricas Concretas (Concrete Factories)
Implementan la fábrica abstracta para crear familias de productos específicos.
- `FabricaMueblesModernos.java`: Crea muebles modernos.
- `FabricaMueblesVictorianos.java`: Crea muebles victorianos.
- `FabricaMueblesArtDeco.java`: Crea muebles ArtDeco.

### 5. Cliente y Demo
- `Cliente.java`: La clase que usa la fábrica. **Nota importante:** El cliente solo trabaja con las interfaces (`Silla`, `FabricaMuebles`, etc.), no sabe qué variante concreta está usando.
- `Demo.java`: El punto de entrada (`main`). Es el responsable de decidir qué fábrica concreta se usa (simulando una configuración) e inyectarla al cliente.

## Diagrama de clases (Mermaid)

```mermaid
classDiagram


class FabricaMuebles {
   <<interface>>
   +crearSilla() Silla
   +crearSofa() Sofa
   +crearMesilla() Mesilla
}

class FabricaMueblesModernos
class FabricaMueblesVictorianos
class FabricaMueblesArtDeco

FabricaMuebles <|.. FabricaMueblesModernos
FabricaMuebles <|.. FabricaMueblesVictorianos
FabricaMuebles <|.. FabricaMueblesArtDeco

class Silla {
   <<interface>>
}
class Sofa {
   <<interface>>
}
class Mesilla {
   <<interface>>
}

class SillaModerna
class SofaModerno
class MesillaModerna

class SillaVictoriana
class SofaVictoriano
class MesillaVictoriana

class SillaArtDeco
class SofaArtDeco
class MesillaArtDeco

Silla <|.. SillaModerna
Sofa  <|.. SofaModerno
Mesilla <|.. MesillaModerna

Silla <|.. SillaVictoriana
Sofa  <|.. SofaVictoriano
Mesilla <|.. MesillaVictoriana

Silla <|.. SillaArtDeco
Sofa  <|.. SofaArtDeco
Mesilla <|.. MesillaArtDeco

FabricaMueblesModernos ..> Silla : crea
FabricaMueblesModernos ..> Sofa : crea
FabricaMueblesModernos ..> Mesilla : crea

FabricaMueblesVictorianos ..> Silla : crea
FabricaMueblesVictorianos ..> Sofa : crea
FabricaMueblesVictorianos ..> Mesilla : crea

FabricaMueblesArtDeco ..> Silla : crea
FabricaMueblesArtDeco ..> Sofa : crea
FabricaMueblesArtDeco ..> Mesilla : crea

class Cliente {
   -fabrica: FabricaMuebles
}
Cliente --> FabricaMuebles : usa

class Demo
Demo ..> FabricaMuebles : selecciona/inyecta
Demo ..> Cliente : ejecuta
```

## Cómo Utilizar

1. **Compilar**:
   Navega a la carpeta `code`.
   ```bash
   javac es/uva/poo/abstractfactory/*.java
   ```

2. **Ejecutar**:
   ```bash
   java es.uva.poo.abstractfactory.Demo
   ```

3. **Cambiar Configuración**:
   Para probar otros estilos, edita `Demo.java` y cambia el valor de la variable `estiloMuebles` ("MODERNO", "VICTORIANO", "ARTDECO").
