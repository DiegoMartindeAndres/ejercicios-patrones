package es.uva.poo.abstractfactory;

/**
 * Implementación concreta de una Silla en estilo Victoriano.
 */
public class SillaVictoriana implements Silla {

    @Override
    public void tienePatas() {
        System.out.println("La Silla Victoriana tiene patas ornamentadas y talladas.");
    }

    @Override
    public void sentarse() {
        System.out.println("Te sientas en una Silla Victoriana. Se siente la historia.");
    }
}
