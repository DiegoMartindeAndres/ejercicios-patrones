package es.uva.poo.abstractfactory;

/**
 * Fábrica Concreta para muebles Victorianos.
 * Crea familias de productos victorianos.
 */
public class FabricaMueblesVictorianos implements FabricaMuebles {

    @Override
    public Silla crearSilla() {
        return new SillaVictoriana();
    }

    @Override
    public Sofa crearSofa() {
        return new SofaVictoriano();
    }

    @Override
    public Mesilla crearMesilla() {
        return new MesillaVictoriana();
    }
}
